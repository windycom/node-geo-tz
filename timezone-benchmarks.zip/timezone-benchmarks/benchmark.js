const Fs = require('fs');
const { fork } = require('child_process');

const testees = ['tzwhere', 'fast', 'geo-o', 'geo-m'];

//------------------------------------------------------------------------------
const runJs = (stream, ...args) => new Promise((resolve, reject) => {
	const cp = fork(...args);

	cp.once('exit', (code) => {
		if (code) {
			reject(new Error(code));
		} else {
			resolve();
		}
	});

	if (stream) {
		cp.on('message', (data) => {
			stream.write(data);
			stream.write('\n');
		});
	}

	cp.once('error', reject);
});

//------------------------------------------------------------------------------
const main = async () => {
	const args = process.argv.slice(2);
	const count = parseInt(args.shift(), 10);
	if (!count) {
		console.error(`Usage: benchmark <count> [...${testees.join('|')}]`);
		process.exit(1);
	}

	if (!args.length) {
		args.push(...testees);
	}

	const stream = Fs.createWriteStream('result.csv');
	//const stream = null;
	stream && stream.write(`"Name"\t"Duration(ms)"\t"Queries/s"\t"Hits"\t"Misses"\n`);
	for (const name of args) {
		console.log(`Benchmark for ${name}`);
		await runJs(stream, `./${name}`, [count]);
		console.log(`DONE ${name}\n************************`);
	}
};

main();
