const tzwhere = require('tzwhere');

const lookup = (lat, long) => {
	try {
		const where = tzwhere.tzNameAt(lat, long);
		console.log('OK:', where);
	} catch (error) {
		console.error('Error thrown:', error.message);
	}
};

tzwhere.init();

lookup(parseFloat(process.argv[2]), parseFloat(process.argv[3]));
