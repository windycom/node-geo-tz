const run = require('../harness');
const tzwhere = require('tzwhere');

const lookup = (lat, long) => {
	try {
		return tzwhere.tzNameAt(lat, long);
	} catch (error) {
		return null;
	}
};

//------------------------------------------------------------------------------
const main = async () => {
	await run('tzwhere', () => tzwhere.init(), lookup);
	process.exit(0);
};

main();
