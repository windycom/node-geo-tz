const Path = require('path');
const Fs = require('fs-extra');

const LIM = 85.0;
const LIM2 = 2 * LIM;

//------------------------------------------------------------------------------
const createLatLong = () => ({
	lat: (Math.random() * 180) - 90,
	long: (Math.random() * 360) - 180,
});

//------------------------------------------------------------------------------
const createLatLongSafe = () => ({
	lat: (Math.random() * LIM2) - LIM,
	long: (Math.random() * 340) - 170,
});

//------------------------------------------------------------------------------
const runTest = (name, count, fn) => {
	const start = new Date();
	let hit = 0;
	let miss = 0;

	for (let n = 0; n < count; n++) {
		const ll = createLatLongSafe();
		const ret = fn(ll.lat, ll.long);
		if (ret) {
			hit++;
		} else {
			miss++;
		}
	}
	const end = new Date();
	const duration = end.getTime() - start.getTime();
	if (process.send) {
		process.send(`"${name}"\t${duration.toFixed()}\t${(count / (duration / 1000)).toFixed()}\t${hit}\t${miss}`);
	}
	process.stdout.write(`\n`);

	console.log(`${count} queries in ${duration.toFixed(1)} ms. That is ${(count / (duration / 1000)).toFixed()} queries per second.`);
	console.log(`Have ${hit} hits and ${miss} misses (${((miss / count) * 100).toFixed()}%).`);
	console.log(`One query takes avg ${((duration * 1000) / count).toFixed(1)} us`);
	console.log(`---------------------------------------------------------------`);
};

//------------------------------------------------------------------------------
const transformFile = (name, inFile, outFile, lookup) => {
	const input = require(inFile);
	const output = input.map(i => lookup(...i));
	return Fs.writeJson(outFile, output);
};

//------------------------------------------------------------------------------
module.exports = async (name, init, lookup) => {
	const args = process.argv.slice(2);

	const arg1 = args.shift();
	const arg2 = args.shift();
	if (arg1 && arg2 && Fs.existsSync(arg1)) {
		console.log('Loading data');
		await init();
		console.log('generating output...');
		await transformFile(name, arg1, arg2, lookup);
		process.exit(0);
	}

	const count = parseInt(arg1, 10);
	if (!count) {
		console.error(`Missing count`);
		process.exit(1);
	}

	console.log('Loading data');
	await init();

	const input = args.shift();
	if (input) {
		console.log('generating output...');
		await transformFile(name, input, lookup);
		process.exit(0);
	}

	console.log('running test...');
	await runTest(name, count, lookup);
	process.exit(0);
};
