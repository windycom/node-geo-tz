const geoTz = require('geo-tz');

const lookup = (lat, long) => {
	try {
		const where = geoTz(lat, long);
		console.log('OK:', where);
	} catch (error) {
		console.error('Error thrown:', error.message);
	}
};

lookup(parseFloat(process.argv[2]), parseFloat(process.argv[3]));
