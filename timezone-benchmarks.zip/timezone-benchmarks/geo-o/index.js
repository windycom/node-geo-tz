const run = require('../harness');
const geoTz = require('geo-tz');

//------------------------------------------------------------------------------
const main = async () => {
	await run('geo-tz-original', () => {}, geoTz);
	process.exit(0);
};

main();
