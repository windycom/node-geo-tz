const getTimezone = require('fast-timezone');

const lookup = (lat, long) => {
	try {
		const where = getTimezone(lat, long).id;
		console.log('OK:', where);
	} catch (error) {
		console.error('Error thrown:', error.message);
	}
};

getTimezone.init().then(() => {
	lookup(parseFloat(process.argv[2]), parseFloat(process.argv[3]));
});
