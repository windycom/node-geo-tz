const run = require('../harness');
const getTimezone = require('fast-timezone');

const getTzName = (lat, long) => {
	return getTimezone(lat, long).id;
};

//------------------------------------------------------------------------------
const main = async () => {
	await run('fast-timezone', () => getTimezone.init(), getTzName);
	process.exit(0);
};

main();
