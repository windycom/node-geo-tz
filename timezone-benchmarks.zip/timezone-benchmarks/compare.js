const Path = require('path');
const Fs = require('fs-extra');
const { fork } = require('child_process');

const testees = ['tzwhere', 'fast', 'geo-o', 'geo-m'];

const LIM = 85.0;
const LIM2 = 2 * LIM;

//------------------------------------------------------------------------------
const createLatLongSafe = () => ([
	(Math.random() * LIM2) - LIM,
	(Math.random() * 340) - 170
]);

//------------------------------------------------------------------------------
const runJs = (...args) => new Promise((resolve, reject) => {
	const cp = fork(...args);

	cp.once('exit', (code) => {
		if (code) {
			reject(new Error(code));
		} else {
			resolve();
		}
	});

	cp.once('error', reject);
});

//------------------------------------------------------------------------------
const main = async () => {
	const args = process.argv.slice(2);
	const count = parseInt(args.shift(), 10);
	if (!count) {
		console.error(`Usage: compare <count> [...${testees.join('|')}]`);
		process.exit(1);
	}

	if (!args.length) {
		args.push(...testees);
	}

	const inputFile = Path.join(__dirname, 'testdata.json');
	if (!Fs.existsSync(inputFile)) {
		console.log(`Creating ${count} queries...`);
		const queries = [];
		for (let n = 0; n < count; n++) {
			queries.push(createLatLongSafe());
		}
		await Fs.writeJson(inputFile, queries);
	}

	const results = {};
	for (const name of args) {
		const outFile = Path.join(__dirname, `testdata.json.${name}.json`);
		if (!Fs.existsSync(outFile)) {
			console.log(`Compare for ${name}`);
			await runJs(`./${name}`, [inputFile, outFile]);
			console.log(`DONE ${name}\n************************`);
		} else {
			console.log(`Skipping ${name}`);
		}
		results[name] = await Fs.readJson(outFile);
	}

	console.log(`Creating result table`);
	const names = Object.keys(results);

	const table = names.map(() => names.map(() => 0));
	for (let row = 0; row < names.length; row++) {
		const left = results[names[row]];
		for (let col = 0; col < names.length; col++) {
			const right = results[names[col]];
			const equal = right.filter((cur, i) => {
				if ((left[i] !== cur) && (names[row] === 'geo-m') && (names[col] === 'fast')) {
					console.log(`${names[row]}:${left[i]} <==> ${names[col]}:${cur}`);
				}
				return left[i] === cur;
			}).length;
			table[col][row] = equal / Math.max(left.length, right.length);
		}
	}

	console.log(`"-"\t${names.join('"\t"')}"`);
	table.forEach((row, i) => {
		console.log(`"${names[i]}"\t${row.join('\t')}`);
	});

	//console.log(table);
	console.log(`DONE`);
};

main();
